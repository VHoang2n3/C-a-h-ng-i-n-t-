import React from 'react'

const QuickView = () => {
    return (
        <div>QuickView</div>
    )
}

export default QuickView