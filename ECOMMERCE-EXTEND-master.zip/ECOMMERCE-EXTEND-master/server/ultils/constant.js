exports.users = [
    {
        email: 'user-01@gmail.com',
        password: 123456,
        firstname: 'Tony 1',
        lastname: 'Jimmy',
        mobile: '01234567788'
    },
    {
        email: 'user-02@gmail.com',
        password: 123456,
        firstname: 'Tony 2',
        lastname: 'Jimmy',
        mobile: '01234567784'
    },
    {
        email: 'user-03@gmail.com',
        password: 123456,
        firstname: 'Tony 3',
        lastname: 'Jimmy',
        mobile: '01234567785'
    },
    {
        email: 'user-04@gmail.com',
        password: 123456,
        firstname: 'Tony 4',
        lastname: 'Jimmy',
        mobile: '01234567780'
    },
]

exports.roles = [
    {
        code: 1945,
        value: 'Admin'
    },
    {
        code: 1979,
        value: 'User'
    },
]
